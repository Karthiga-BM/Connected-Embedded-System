// Based on the Paho C code example from www.eclipse.org/paho/
#include <iostream>
#include <sstream>
#include <fstream>
#include <string.h>
#include <time.h>
#include "MQTTClient.h"
#include "ADXL345.h"
#include <unistd.h>
#include <pthread.h>


#define  CPU_TEMP "/sys/class/thermal/thermal_zone0/temp"
#define DATE "date"

using namespace std;
using namespace exploringRPi;

//Please replace the following address with the address of your server
#define ADDRESS    "tcp://192.168.137.1:1883"
#define CLIENTID   "rpi1"
#define AUTHMETHOD "karthi"
#define AUTHTOKEN  "root"
#define TOPIC      "ee513/CPUTemp"
#define QOS        1
#define TIMEOUT    10000L


float getCPUTemperature() {        // get the CPU temperature
   int cpuTemp;                    // store as an int
   fstream fs;
   fs.open(CPU_TEMP, fstream::in); // read from the file
   fs >> cpuTemp;
   fs.close();
   return (((float)cpuTemp)/1000);
}


//time Function
char* asctime(const struct tm *timeptr)
{
  static const char wday_name[][4] = {
    "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"
  };
  static const char mon_name[][4] = {
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
  };
  static char result[26];
  sprintf(result, "%.3s %.3s%3d %.2d:%.2d:%.2d %d\n",
    wday_name[timeptr->tm_wday],
    mon_name[timeptr->tm_mon],
    timeptr->tm_mday, timeptr->tm_hour,
    timeptr->tm_min, timeptr->tm_sec,
    1900 + timeptr->tm_year);
  return result;
}






// Main Function

   int main(int argc, char* argv[]) {
   char str_payload[100];          // Set your max message size here
   char str_payload1[100];
   char str_payload2[100];
   int i = 10;
  
  
   
   
   
   MQTTClient client;
   
   //ADXL345 Code
   ADXL345 sensor(1,0x53);
   sensor.setResolution(ADXL345::NORMAL);
   sensor.setRange(ADXL345::PLUSMINUS_4_G);
   sensor.displayPitchAndRoll();
      
      
   //MQTT client
   MQTTClient_connectOptions opts = MQTTClient_connectOptions_initializer;
   MQTTClient_message pubmsg = MQTTClient_message_initializer;
   
   //MQTT LastWill Message
   
   MQTTClient_willOptions willoptions = MQTTClient_willOptions_initializer; 
  

 
   MQTTClient_deliveryToken token;
   MQTTClient_create(&client, ADDRESS, CLIENTID, MQTTCLIENT_PERSISTENCE_NONE, NULL);
   opts.keepAliveInterval = 20;
   opts.cleansession = 1;
   opts.username = AUTHMETHOD;
   opts.password = AUTHTOKEN;
   int rc;
   if ((rc = MQTTClient_connect(client, &opts)) != MQTTCLIENT_SUCCESS) {
      cout << "Failed to connect, return code " << rc << endl;
      return -1;
   }
   
   //Temperature
   sprintf(str_payload, "{\"d\":{\"CPUTemp\": %f }}", getCPUTemperature());
   pubmsg.payload = str_payload;
   pubmsg.payloadlen = strlen(str_payload);
   pubmsg.qos = QOS;
   pubmsg.retained = 0;
   
   
    
   
     
    //Get time from the RPI
  time_t rawtime;
  struct tm * timeinfo;
  time ( &rawtime );
  timeinfo = localtime ( &rawtime );
  sprintf(str_payload1, "{\"d\":{\"date/time\": %s }}", asctime(timeinfo)); 
  pubmsg.payload = str_payload1;
   pubmsg.payloadlen = strlen(str_payload1);
   pubmsg.qos = QOS;
   pubmsg.retained = 0;
   
  
   
   //LastWill Options Value
   sprintf(str_payload2, "LastWill");
   
   willoptions.topicName = "ee513/test";
   willoptions.message = "Publisher Disconnected";
   willoptions.qos = QOS;
   willoptions.retained = 0;
   
   
   
   
   MQTTClient_publishMessage(client, TOPIC, &pubmsg, &token);
   
   cout << "Waiting for up to " << (int)(TIMEOUT/1000) <<
        " seconds for publication of " << str_payload << 
        "\nand the time " << str_payload1 <<
        " on topic " << TOPIC << " for ClientID: " << CLIENTID <<  endl;
   rc = MQTTClient_waitForCompletion(client, token, TIMEOUT);
   cout << " \n Message with token " << (int)token << " delivered." << endl;
   
  
   
   
   MQTTClient_disconnect(client, 10000);
   MQTTClient_destroy(&client);
   return rc;
    
}

