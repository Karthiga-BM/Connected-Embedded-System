#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "MQTTClient.h"

extern "C" {
#include <wiringPi.h>
}

#define ADDRESS     "tcp://192.168.137.1:1883"
#define CLIENTID    "rpi3"
#define AUTHMETHOD  "karthi"
#define AUTHTOKEN   "root"
#define TOPIC       "ee513/time"
#define PAYLOAD     "Hello World!"
#define QOS         1
#define TIMEOUT     10000L
#define LedPin 0 //LED light

volatile MQTTClient_deliveryToken deliveredtoken;

void delivered(void *context, MQTTClient_deliveryToken dt) {
    printf("Message with token value %d delivery confirmed\n", dt);
    deliveredtoken = dt;
}
//Lighting LED
int wiringPiSetup(void);
void pinMode(int pin,int mode);
void digitalWrite(int pin, int value);
void delay(unsigned int howLong);

int msgarrvd(void *context, char *topicName, int topicLen, MQTTClient_message *message) {
    int i;
    char* payloadptr;
    printf("Message arrived\n");
    printf("     topic: %s\n", topicName);
    printf("   message: ");
    payloadptr = (char*) message->payload;
    
        
    
    for(i=0; i<message->payloadlen; i++) {
    putchar(*payloadptr++);
        }
        
    //Lighting LED
    
    if(message != NULL )//setting the condition that if the displayed message is not null then LED blinks
    {
    
        if(wiringPiSetup() == -1) { //when initialize wiringPi failed, print message to screen
                printf("setup wiringPi failed !\n");
                return -1;
        }

        pinMode(LedPin, OUTPUT);
        while(1) {
                digitalWrite(LedPin, LOW);   //led on
                printf("led on\n");
                delay(1000);			     // wait 1 sec
                digitalWrite(LedPin, HIGH);  //led off
                printf("led off\n");
                delay(1000);                 // wait 1 sec
        }
      
         printf("\n LED Lights");
        }
       
        
    
    
    
    putchar('\n');
    MQTTClient_freeMessage(&message);
    MQTTClient_free(topicName);
    return 1;
}

//sprintf(str_payload, "{\"d\":{\"message\": %f }}", getCPUTemperature());



void connlost(void *context, char *cause) {
    printf("\nConnection lost\n");
    printf("     cause: %s\n", cause);
}

int main(int argc, char* argv[]) {
    MQTTClient client;
    MQTTClient_connectOptions opts = MQTTClient_connectOptions_initializer;
    int rc;
    int ch;

    MQTTClient_create(&client, ADDRESS, CLIENTID, MQTTCLIENT_PERSISTENCE_NONE, NULL);
    opts.keepAliveInterval = 20;
    opts.cleansession = 1;
    opts.username = AUTHMETHOD;
    opts.password = AUTHTOKEN;

    MQTTClient_setCallbacks(client, NULL, connlost, msgarrvd, delivered);
    if ((rc = MQTTClient_connect(client, &opts)) != MQTTCLIENT_SUCCESS) {
        printf("Failed to connect, return code %d\n", rc);
        exit(-1);
    }
    printf("Subscribing to topic %s\nfor client %s using QoS%d\n\n"
           "Press Q<Enter> to quit\n\n", TOPIC, CLIENTID, QOS);
    MQTTClient_subscribe(client, TOPIC, QOS);
    
    
    
        

    do {
        ch = getchar();
    } while(ch!='Q' && ch != 'q');
    MQTTClient_disconnect(client, 10000);
    MQTTClient_destroy(&client);
    return rc;
}

